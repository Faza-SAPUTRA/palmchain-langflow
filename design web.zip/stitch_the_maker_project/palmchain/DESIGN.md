---
name: PalmChain
colors:
  surface: '#131417'
  surface-dim: '#121315'
  surface-bright: '#38393b'
  surface-container-lowest: '#0d0e10'
  surface-container-low: '#1b1c1e'
  surface-container: '#1f2022'
  surface-container-high: '#292a2c'
  surface-container-highest: '#343537'
  on-surface: '#e3e2e5'
  on-surface-variant: '#c3c9ae'
  inverse-surface: '#e3e2e5'
  inverse-on-surface: '#303033'
  outline: '#8d937b'
  outline-variant: '#434934'
  surface-tint: '#a2d801'
  primary: '#ffffff'
  on-primary: '#263500'
  primary-container: '#bdf532'
  on-primary-container: '#516e00'
  inverse-primary: '#4c6700'
  secondary: '#f3be65'
  on-secondary: '#432c00'
  secondary-container: '#7e5700'
  on-secondary-container: '#ffd28a'
  tertiary: '#ffffff'
  on-tertiary: '#68000d'
  tertiary-container: '#ffdad7'
  on-tertiary-container: '#bc2c32'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#bdf532'
  primary-fixed-dim: '#a2d801'
  on-primary-fixed: '#141f00'
  on-primary-fixed-variant: '#384e00'
  secondary-fixed: '#ffdeac'
  secondary-fixed-dim: '#f3be65'
  on-secondary-fixed: '#281900'
  on-secondary-fixed-variant: '#604100'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3af'
  on-tertiary-fixed: '#410005'
  on-tertiary-fixed-variant: '#910519'
  background: '#121315'
  on-background: '#e3e2e5'
  surface-variant: '#343537'
  surface-hover: '#1C1E22'
  border-hairline: rgba(255, 255, 255, 0.08)
  text-primary: '#F5F6F7'
  text-muted: '#8A8F98'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  technical-data:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  technical-label:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-width: 240px
  grid-gutter: 16px
  container-margin: 24px
  bento-gap: 12px
  padding-card: 20px
---

## Brand & Style

The design system embodies the identity of **PalmChain**, a high-integrity, fintech-grade infrastructure tool for blockchain-based palm oil traceability. The brand personality is professional, technical, and authoritative, designed to instill trust in complex supply chain data and EUDR (European Union Deforestation Regulation) compliance.

The visual direction follows a **Modern / Minimalist** aesthetic with a distinctive **dark-mode-first** approach. It avoids heavy glassmorphism or generic SaaS trends in favor of high-precision typography and "hairline" geometry.

**Key Stylistic Pillars:**
- **Obsidian Dark Mode:** A deep, near-black foundation that emphasizes technical data and reduces eye strain for long-term monitoring.
- **Precision Infrastructure:** High-contrast, hairline borders (1px) define the space, creating a sense of "engineered" clarity.
- **Strategic High-Contrast:** The "Acid Green" accent is used with extreme discipline, reserved exclusively for verification status, critical data, and micro-interactions to prevent visual fatigue.
- **Bento-Grid Structure:** Content is organized into modular "Bento" tiles that allow for dense information displays while maintaining clear visual hierarchy and breathing room.

## Colors

The palette is designed for a technical environment where color is an information signal rather than just decoration.

- **Primary (Acid Green):** Used for "Verified" statuses, active navigation states, and critical performance indicators. It must be used sparingly to maintain its impact.
- **Secondary (Palm Gold):** Dedicated to authenticity badges and specific palm oil quality metrics, providing a warmer contrast to the technical green.
- **Tertiary (Soft Red):** Reserved strictly for anomalies, fraud flags, or EUDR violations.
- **Neutrals:** The background is an absolute "Obsidian" (#0A0B0D). Surfaces are slightly lifted to #131417 to create subtle depth. All borders must use the hairline specification (1px with 8% white opacity) to maintain the minimalist infrastructure feel.

## Typography

Typography in this design system differentiates between UI narrative and technical evidence.

- **Headings & UI (Hanken Grotesk):** A geometric sans-serif that provides a clean, modern infrastructure feel. Large headings should use tighter tracking (-0.02em) to appear more "impactful" and precise.
- **Body & Description (Inter):** Used for all explanatory text and descriptive copy (Bahasa Indonesia) to ensure maximum readability and a neutral tone.
- **Data & Identifiers (JetBrains Mono):** This is a critical component of the system. All technical data—including Blockchain hashes, Asset IDs, GPS coordinates, and weights—must use the monospaced font. This reinforces the "Blockchain Tool" credibility and allows for easy comparison of alphanumeric strings.

## Layout & Spacing

The system utilizes a **Fixed Sidebar + Bento Grid** model.

**Structure:**
- **Sidebar:** A fixed 240px left-hand column for primary navigation.
- **Top Bar:** A slim, consistent header for breadcrumbs and global actions.
- **Main Content:** A flexible grid using a "Bento" approach where cards vary in span but maintain a consistent 12px gap.
- **Responsive Behavior:** 
  - **Desktop (1280px+):** Full 12-column grid layout.
  - **Tablet (768px - 1279px):** Sidebar collapses to icons-only; grid reflows to 2 columns.
  - **Mobile (<767px):** Sidebar becomes a bottom navigation bar or hidden drawer; all Bento cards stack vertically to 100% width.

Spacing follows an 8px base unit, though hairline borders and tight gaps (12px) are preferred to maximize information density without clutter.

## Elevation & Depth

In line with the minimalist-infrastructure aesthetic, the design system avoids heavy shadows and traditional depth metaphors.

- **Tonal Layering:** Depth is communicated through color shifts. The background is `#0A0B0D`, while interactive containers (cards) are `#131417`.
- **Hairline Borders:** Instead of shadows, 1px borders with low opacity (`rgba(255,255,255,0.08)`) define the boundaries of elements.
- **Interaction States:** On hover, cards should not use heavy shadows. Instead, apply a subtle "lift" (2-4px Y-translation) and increase the border opacity or add a faint Acid Green tint to the border to indicate focus.
- **No Glassmorphism:** Background blurs should be avoided to maintain a "sharp" and "performant" feel.

## Shapes

The shape language is "Soft" yet disciplined. While the overall aesthetic is sharp and technical, small corner radii prevent the UI from feeling aggressive.

- **Cards/Containers:** Use a `0.5rem` (8px) radius.
- **Buttons & Inputs:** Use a consistent `0.25rem` (4px) radius for a more "tool-like" appearance.
- **Status Badges:** Use a pill-shaped (fully rounded) radius to distinguish them from structural UI elements.
- **Icons:** Should follow a linear, 2px stroke weight to match the hairline border aesthetic.

## Components

- **Buttons:** Primary buttons use a solid Acid Green (#C6FF3D) background with black text. Secondary buttons use a transparent background with a hairline border and white text. 
- **Status Badges:** Compact labels with a subtle background tint and bold text. "Verified" uses a green tint, "Flagged" uses a soft red tint, and "Authentic" uses a gold tint.
- **Data Tables:** High-density rows with hairline separators. All alphanumeric IDs in the table must use `technical-data` (JetBrains Mono).
- **Inputs:** Dark background (#0A0B0D), hairline border, and a 2px Acid Green left-border on focus. Monospace font is used for API key and technical fields.
- **Bento Cards:** Standard container for all dashboard modules. Must include a consistent 20px internal padding.
- **IoT Indicators:** Status dots for devices (e.g., Online) should use a subtle "pulse" animation with a 2px outer glow in the primary accent color.
- **Floating Chatbot:** A small, circular button in the bottom right that expands into a vertical panel, maintaining the dark theme with Acid Green message bubbles for the user.