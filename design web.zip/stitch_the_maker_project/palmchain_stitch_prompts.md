# PalmChain — Stitch Prompt Set (5 Halaman)

Cara pakai: paste **satu prompt per generation** ke Stitch, urut dari 1 → 5. Design system (warna, font, layout, komponen) sengaja ditulis identik di tiap prompt supaya Stitch menghasilkan tampilan yang nyambung dan konsisten antar halaman — bukan lima desain yang beda arah.

Bahasa di dalam UI: label/aksi pakai **English** (Overview, Export, Add Device, dst), copy/deskripsi/penjelasan pakai **Bahasa Indonesia**.

---

## Design System (dipakai di semua prompt di bawah)

```
Product: PalmChain — dashboard traceability rantai pasok sawit (petani → pengepul), berbasis blockchain EVM + IoT + AI, untuk kepatuhan EUDR.

Visual direction: minimalis premium, gelap, terasa "fintech-grade infrastructure tool" — bukan template SaaS generik, bukan glassmorphism berat. Terinspirasi dashboard kelas Linear, Vercel, Stripe: hairline border tipis, tipografi presisi, whitespace lega, satu accent color yang dipakai hemat dan disiplin.

Color palette:
- Background: near-black obsidian #0A0B0D
- Surface: #131417, surface hover #1C1E22
- Border: hairline 1px, rgba(255,255,255,0.08)
- Accent utama: acid/bio green #C6FF3D — pakai HANYA untuk elemen aktif, status "verified", angka penting, dan micro-interaction. Jangan dominan.
- Accent sekunder: palm gold #D4A24C — untuk badge "authentic/compliant" dan highlight terkait hasil sawit
- Alert/anomaly: soft red #FF5D5D — dipakai sangat jarang, untuk flag kecurangan/pelanggaran EUDR
- Text primary: #F5F6F7, text muted: #8A8F98

Typography:
- Heading & UI: geometric grotesk sans (gaya Geist/General Sans), tegas, tracking rapat di heading besar
- Body/copy: Inter
- Data numerik, hash, ID transaksi, koordinat GPS: monospace (JetBrains Mono/IBM Plex Mono) — dipakai konsisten setiap kali menampilkan data teknis, ini penting untuk kredibilitas "blockchain tool"

Layout:
- Fixed left sidebar (± 240px): logo PalmChain kecil di atas, nav vertikal dengan icon (Overview, Transactions, IoT Devices, Assets, Settings), sidebar collapsible
- Top bar: breadcrumb halaman, search bar kecil, notification bell, avatar profil di kanan
- Konten utama pakai grid/bento layout, radius sudut kecil (8-10px), border hairline — hindari shadow tebal atau blur berlebihan
- Floating chatbot widget tetap ada di pojok kanan bawah di semua halaman: ikon bulat kecil, saat diklik expand jadi panel chat gelap dengan bubble hijau accent untuk pesan user

Animasi (ringan, jangan berlebihan):
- Fade-up halus + stagger singkat saat elemen/card muncul pertama kali
- Angka statistik melakukan count-up singkat saat halaman dibuka
- Hover pada card: lift 2-4px + border menyala tipis warna accent
- Indikator nav aktif di sidebar bergeser halus saat pindah menu
- Tidak ada parallax berat, tidak ada partikel ramai, tidak ada scroll-jacking
```

---

## Prompt 1 — Overview / Dashboard (halaman utama)

```
[Design System di atas]

Buatkan halaman Overview untuk PalmChain, halaman pertama yang dilihat user setelah login.

Struktur konten:
1. Header halaman: judul "Overview" + subtext singkat berbahasa Indonesia menjelaskan ringkasan status rantai pasok hari ini, plus tombol "Export Report" di kanan atas.
2. Baris 3 stat card (bento style, hairline border): Total Supply (kg, dengan mini sparkline tren 7 hari), Active Farmers (jumlah petani aktif), Smart Contract Status (badge "Active" warna accent hijau).
3. Panel besar "Supply Chain Flow": visualisasi alur sederhana dari Farmer → Collector → Mill dalam bentuk node-and-line horizontal minimalis (bukan peta geografis), tiap node menunjukkan jumlah transaksi berjalan.
4. Panel "Recent On-Chain Activity": list 5 transaksi terbaru, masing-masing menampilkan asset ID (monospace), berat, grade, status verifikasi (badge hijau "Verified" / abu-abu "Pending"), dan waktu relatif ("2 menit lalu").
5. Panel kecil "Compliance Snapshot": indikator lingkaran progress EUDR compliance rate (%) dengan copy singkat penjelasan dalam Bahasa Indonesia.

Sidebar item "Overview" dalam kondisi aktif. Terapkan seluruh design system dan animasi ringan di atas.
```

---

## Prompt 2 — Asset Detail / Traceability

```
[Design System di atas]

Buatkan halaman Asset Detail untuk satu aset kelapa sawit (contoh ID: TBS-20260821-001) di PalmChain, diakses dari klik salah satu transaksi di halaman Overview.

Struktur konten:
1. Header: Asset ID besar dalam monospace + badge status "Verified on-chain" (hijau) di sampingnya, breadcrumb "Overview / Asset Detail".
2. Timeline custody vertikal: tiga tahap — Farmer (nama, lokasi kebun), Collector (nama, waktu timbang), Mill (tujuan akhir) — tiap tahap punya timestamp dan ikon status.
3. Panel "IoT Sensor Data": grid kecil menampilkan berat (kg dari load cell), koordinat GPS (monospace), thumbnail foto dari kamera ESP32, dan waktu capture.
4. Panel "Blockchain Record": menampilkan transaction hash (dipotong dengan ellipsis, monospace), block number, smart contract address, dengan tombol kecil "Copy" dan "View on Explorer".
5. Panel "EUDR Compliance Check": badge status compliant/non-compliant dengan penjelasan singkat berbahasa Indonesia tentang kenapa (misal: lokasi kebun berada di luar zona deforestasi terpantau).
6. Peta kecil minimalis (style monokrom gelap) menunjukkan titik lokasi GPS aset dengan pin accent hijau.

Sidebar tidak ada item yang aktif secara eksplisit (halaman detail), tapi highlight breadcrumb ke "Overview". Terapkan seluruh design system dan animasi ringan di atas.
```

---

## Prompt 3 — Transactions (Blockchain Ledger)

```
[Design System di atas]

Buatkan halaman Transactions untuk PalmChain, menampilkan seluruh histori transaksi on-chain rantai pasok sawit.

Struktur konten:
1. Header: judul "Transactions" + search bar untuk cari berdasarkan Asset ID atau hash, plus filter dropdown (Status: All/Verified/Pending, Date range).
2. Tabel utama dengan kolom: Asset ID (monospace), Farmer, Weight (kg), Grade, Timestamp, Tx Hash (dipotong, monospace), Status (badge berwarna: hijau "Verified", abu-abu "Pending", merah lembut "Flagged" untuk anomali).
3. Baris tabel bisa di-hover dengan efek highlight ringan, klik baris membuka detail (menuju halaman Asset Detail).
4. Pagination sederhana di bawah tabel.
5. Panel ringkasan kecil di atas tabel: total transaksi hari ini, jumlah flagged/anomali, rata-rata waktu verifikasi — tampil sebagai 3 angka kecil sejajar dengan label muted.

Sidebar item "Transactions" dalam kondisi aktif. Terapkan seluruh design system dan animasi ringan di atas — termasuk fade-up stagger untuk baris tabel saat halaman dimuat.
```

---

## Prompt 4 — IoT Devices (Monitoring)

```
[Design System di atas]

Buatkan halaman IoT Devices untuk PalmChain, menampilkan status seluruh perangkat ESP32 (GPS + load cell + kamera) yang terpasang di lapangan.

Struktur konten:
1. Header: judul "IoT Devices" + tombol "Add Device" di kanan atas, plus toggle filter status (Online/Offline/All).
2. Grid card perangkat (2-3 kolom): tiap card menampilkan nama/ID device (monospace), indikator status online (dot hijau berdenyut halus) / offline (dot abu-abu), lokasi kebun terakhir, level baterai (bar kecil), dan waktu ping GPS terakhir.
3. Klik salah satu card membuka panel detail di sisi kanan (drawer) berisi grafik kecil histori sinyal/baterai 24 jam terakhir dan log aktivitas sensor terbaru.
4. Panel ringkasan di atas grid: total device terpasang, jumlah online sekarang, jumlah butuh perhatian (baterai rendah/offline) — tampil sebagai 3 angka kecil dengan label muted, warna accent untuk angka online.

Sidebar item "IoT Devices" dalam kondisi aktif. Terapkan seluruh design system dan animasi ringan di atas, termasuk denyut halus pada dot status online.
```

---

## Prompt 5 — Settings

```
[Design System di atas]

Buatkan halaman Settings untuk PalmChain, tempat konfigurasi akun, koneksi AI, dan jaringan blockchain.

Struktur konten (gunakan tab horizontal di bawah header untuk memisahkan section: Profile, AI & API Keys, Blockchain Network, Team, Notifications):
1. Header: judul "Settings" dengan subtext singkat berbahasa Indonesia.
2. Tab "Profile": form nama, email, avatar, role.
3. Tab "AI & API Keys": field untuk Langflow API Key dan Gemini API Key (masked dengan opsi show/hide, style input monospace), tombol "Test Connection" dengan indikator status kecil.
4. Tab "Blockchain Network": field RPC endpoint (Hardhat local), Smart Contract Address (monospace), Network status badge ("Connected" hijau).
5. Tab "Team": list anggota tim dengan role masing-masing dan tombol "Invite Member".
6. Tab "Notifications": beberapa toggle switch untuk preferensi notifikasi (transaksi baru, device offline, anomali terdeteksi) dengan style switch minimalis warna accent hijau saat aktif.

Sidebar item "Settings" dalam kondisi aktif. Terapkan seluruh design system dan animasi ringan di atas — termasuk transisi halus saat berpindah tab.
```

---

### Catatan
- Setelah 5 halaman ini jadi di Stitch, screenshot/export tiap halaman bisa dipakai sebagai referensi visual untuk prompt lanjutan ke AI Builder (Bolt/v0/Lovable/dsb) yang akan generate kode aktual — logic chatbot Langflow di `main.js` tidak perlu disentuh, cukup markup & style-nya yang diganti.
- Kalau ada halaman yang hasilnya kurang pas, cukup jalankan ulang prompt halaman itu saja — tidak perlu ulang dari Prompt 1.
